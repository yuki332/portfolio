$('.home-button').click(function(){
  console.log('click');
});
